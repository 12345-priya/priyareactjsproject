import React from "react";

function Boot(){
  return (
    <div className="note">
      <h1>React Js Bootcamp </h1>
    <p>This is the last day of the bootcamp which covers the entire project as 
      it is </p>
    </div>
  );
}
export default Boot;
